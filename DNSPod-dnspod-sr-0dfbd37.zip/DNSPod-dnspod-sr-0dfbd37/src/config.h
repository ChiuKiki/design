#ifndef __CONFIG_H__
#define __CONFIG_H__

#define SR_CONFIG_FILE "../sr.conf"
#define SR_ROOT_FILE "../root.z"
#define SR_RECORDS_FILE "../records.z"

#endif
